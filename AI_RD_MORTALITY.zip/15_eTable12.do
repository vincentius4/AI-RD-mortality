* eTable 12. Treatment within 72 h of admission at the threshold (part 1) and vasopressor or inotrope at hospitals B and C by day and by time after the alert (part 2); window 5
* Part 1 uses $W/base_flags.dta (made in 12_eTable9.do); part 2 the markers in process_t90_v2.dta
use "$W/base.dta", clear
merge 1:1 adm_id using "process_t90_v2.dta", keep(match) nogen
save "$W/base_pm.dta", replace
topen
prow "Outcome (hospitals)" "Before implementation, No. (%)" "After implementation, No. (%)" "DiD-RD" "Post-RD" "Pre-RD"
prow "" "Below" "Above" "Below" "Above" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "OR (95% CI)" "P value"
prow_mark a_any  ABC "Any measured treatment (A-C)"   "$W/base_flags.dta"
prow_mark a_abx  AC  "Intravenous antibiotic (A, C)"  "$W/base_flags.dta"
prow_mark a_bc   ABC "Blood culture (A-C)"            "$W/base_flags.dta"
prow_mark a_lac  BC  "Lactate measurement (B, C)"     "$W/base_flags.dta"
prow_mark a_o2   ABC "Oxygen escalation (A-C)"        "$W/base_flags.dta"
prow_mark a_vaso ABC "Vasopressor or inotrope (A-C)"  "$W/base_flags.dta"
prow "Outcome (hospitals)" "Before implementation, No. (%)" "After implementation, No. (%)" "DiD-RD" "Post-RD" "Pre-RD"
prow "" "Below" "Above" "Below" "Above" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "OR (95% CI)" "P value"
prow_mark vaso_all_Bd0_any  BC "Day 0 (admission day)"   "$W/base_pm.dta"
prow_mark vaso_all_Bd2_any  BC "Day 2"                   "$W/base_pm.dta"
prow_mark vaso_all_Bd3_any  BC "Day 3"                   "$W/base_pm.dta"
prow_mark vaso_all_A24h_any BC "0-24 h after the alert"  "$W/base_pm.dta"
prow_mark vaso_all_A48h_any BC "0-48 h after the alert"  "$W/base_pm.dta"
prow_mark vaso_all_A72h_any BC "0-72 h after the alert"  "$W/base_pm.dta"
tsave "eTable 12"
