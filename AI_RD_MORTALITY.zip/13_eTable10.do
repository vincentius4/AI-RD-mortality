* eTable 10. Alternative assignment variables (in-hospital death)
use "$W/base.dta", clear
merge 1:1 adm_id using "alt_assign_v1.dta", keep(match) nogen
save "$W/base_alt.dta", replace
topen
prow "Assignment variable and window" "Admissions, No." "Deaths, No." "DiD-RD" "Post-RD" "Pre-RD"
prow "" "" "" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "OR (95% CI)" "P value"
foreach k in 1 2 3 4 {
    use "$W/base_alt.dta", clear
    local h = cond(`k' == 3, 8, 5)
    if `k' == 1 local lab "Highest value in the first 24 h (primary), ±5"
    if inlist(`k', 2, 3) {
        local lab "First value at or above the threshold within 24 h, ±`h'"
        qui replace s = rv_first24 - $CUT
    }
    if `k' == 4 {
        local lab "Highest value over the whole stay, ±5"
        qui replace s = rv_whole - $CUT
    }
    qui replace D = (s >= 0)
    trio, h(`h') outcome(death)
    foreach x in dd ddlo ddhi ddp ev n po polo pohi pop pr prlo prhi prp {
        local `x' = r(`x')
    }
    fn `n'
    local c `""`r(s)'" "`ev'""'
    foreach e in dd po pr {
        orci ``e'' ``e'lo' ``e'hi' to
        local c `"`c' "`r(s)'""'
        fp ``e'p'
        local c `"`c' "`r(s)'""'
    }
    prow "`lab'" `c'
}
tsave "eTable 10"
