* Run all: every table of the paper (Table 1-2, eTable 1-14) to results/JAMA_tables.xlsx, one sheet per table, and the figures to results/figures/
* 18_figures.do starts with clear all, so it runs last
do 01_data_and_programs.do
do 02_Table1.do
do 03_Table2.do
do 04_eTable1.do
do 05_eTable2.do
do 06_eTable3.do
do 07_eTable4.do
do 08_eTable5.do
do 09_eTable6.do
do 10_eTable7.do
do 11_eTable8.do
do 12_eTable9.do
do 13_eTable10.do
do 14_eTable11.do
do 15_eTable12.do
do 16_eTable13.do
do 17_eTable14.do
do 19_Figure3_eFigure6.do
do 18_figures.do
