* eTable 8. Secondary outcomes and sensitivity analyses (window 5)
use "$W/base.dta", clear
gen byte o6 = (death == 1) | (arr_any == 1) | (icu_uit_24h == 1)
foreach hh in B C {
    foreach ss in summer fall winter {
        gen double h`hh'_`ss' = h`hh'*`ss'
    }
}
save "$W/base_e8.dta", replace
topen
prow "" "Difference-in-discontinuities" "Single RD after implementation"
prow "Outcome or analysis" "Events" "OR (95% CI)" "P value" "OR (95% CI)" "P value"
prow "Secondary outcomes" "" "" "" "" ""
local R1 "Death or ward cardiac arrest|comp_gw"
local R2 "Death or any cardiac arrest|comp_any"
local R3 "Any cardiac arrest or death without a DNR order|arr_nondnr"
local R4 "Death, any cardiac arrest or unplanned intensive care transfer|o6"
local R5 "Ward cardiac arrest|arr_gw"
local R6 "Unplanned transfer to intensive care after 24 h|icu_uit_24h"
forvalues r = 1/6 {
    tokenize "`R`r''", parse("|")
    local lab "`1'"
    local y "`3'"
    didisc, h(5) outcome(`y')
    local ev = r(ev)
    local p = r(p)
    orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' -
    local a "`r(s)'"
    fp `p'
    local b "`r(s)'"
    srd, h(5) post(1) outcome(`y')
    local p = r(p)
    orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' -
    local c "`r(s)'"
    fp `p'
    prow "`lab'" "`ev'" "`a'" "`b'" "`c'" "`r(s)'"
}
prow "Sensitivity analyses" "" "" "" "" ""
* Events column: admissions removed below / above the threshold (NA = none removed)
foreach k in 1 2 3 4 {
    use "$W/base_e8.dta", clear
    local cv "$COVS"
    local rem "NA"
    if `k' == 1 {
        local lab "Excluding any DNR order during stay"
        qui count if abs(s) < 5 & D == 0 & dnr_case == 1
        local r0 = r(N)
        qui count if abs(s) < 5 & D == 1 & dnr_case == 1
        local rem "−`r0' / −`r(N)'"
        qui drop if dnr_case == 1
    }
    if `k' == 2 {
        local lab "Season terms removed"
        local cv "age_z male cci htn sofa surgical_dept"
    }
    if `k' == 3 {
        local lab "Hospital-by-season terms added"
        local cv "$COVS hB_summer hB_fall hB_winter hC_summer hC_fall hC_winter"
    }
    if `k' == 4 {
        local lab "Summer admissions excluded"
        qui count if abs(s) < 5 & D == 0 & summer == 1
        local r0 = r(N)
        qui count if abs(s) < 5 & D == 1 & summer == 1
        local rem "−`r0' / −`r(N)'"
        qui drop if summer == 1
        local cv "age_z male cci htn sofa surgical_dept fall winter"
    }
    didisc, h(5) covs(`cv')
    local p = r(p)
    fnum `=exp(r(b))' 2
    local a "`r(s)'"
    fp `p'
    local b "`r(s)'"
    srd, h(5) post(1) covs(`cv')
    local p = r(p)
    fnum `=exp(r(b))' 2
    local c "`r(s)'"
    fp `p'
    prow "`lab'" "`rem'" "`a'" "`b'" "`c'" "`r(s)'"
}
tsave "eTable 8"
