* eTable 3. Events during the admission within 5 points of the alert threshold
use "$W/base.dta", clear
keep if abs(s) < 5
local G1 "post == 0 & D == 0"
local G2 "post == 0 & D == 1"
local G3 "post == 1 & D == 0"
local G4 "post == 1 & D == 1"
topen
prow "Event" "Before implementation, No. (%)" "After implementation, No. (%)"
local c
forvalues g = 1/4 {
    qui count if `G`g''
    local lab = cond(inlist(`g', 1, 3), "Score 85-89", "Score 90-94")
    local c `"`c' "`lab' (n = `r(N)')""'
}
prow "" `c'
local R1 "Sepsisa|sepsis"
local R2 "DNR order|dnr_case"
local R3 "Unplanned transfer to intensive care after 24 h|icu_uit_24h"
local R4 "Ward cardiac arrest|arr_gw"
local R5 "In-hospital death|death"
forvalues r = 1/5 {
    tokenize "`R`r''", parse("|")
    local c
    forvalues g = 1/4 {
        npc `3' "`G`g''"
        local c `"`c' "`r(s)'""'
    }
    prow "`1'" `c'
}
local c
forvalues g = 1/4 {
    miqr total_los "`G`g''" 1
    local c `"`c' "`r(s)'""'
}
prow "Length of stay, median (IQR), d" `c'
tsave "eTable 3"
