* eTable 11. Charting frequency between 24 and 72 h and discharge alive within 3 days
use "$W/base.dta", clear
gen double hrs = min(max(h_stay - 24, 0), 48)
gen double rate = n_24_72/hrs if hrs > 0
topen
prow "Outcome" "Window" "Period" "Below threshold" "At or above" "Discontinuity" "P value"
foreach y in rate disc3 {
    local m = cond("`y'" == "disc3", 100, 1)
    local first = 1
    foreach h in 5 8 {
        foreach p in 0 1 2 {
            preserve
            qui keep if abs(s) < `h' & `y' < .
            if `p' < 2 qui keep if post == `p'
            mkw `h' tri
            qui gen double Ds = D*s
            if `p' < 2 {
                qui su `y' if D == 0
                local mb = `m'*r(mean)
                qui su `y' if D == 1
                local ma = `m'*r(mean)
                qui regress `y' D s Ds hB hC $COVS [pw=kw], vce(cluster clust)
                seadj
                local est = `m'*_b[D]
                local pv = 2*normal(-abs(_b[D]/(_se[D]*r(adj))))
            }
            else {
                qui gen double pD = post*D
                qui gen double ps = post*s
                qui gen double pDs = post*D*s
                qui gen double hB_post = hB*post
                qui gen double hC_post = hC*post
                qui gen double hB_D = hB*D
                qui gen double hC_D = hC*D
                qui regress `y' D s Ds post pD ps pDs hB hC hB_post hC_post hB_D hC_D $COVS [pw=kw], vce(cluster clust)
                seadj
                local est = `m'*_b[pD]
                local pv = 2*normal(-abs(_b[pD]/(_se[pD]*r(adj))))
                local mb = .
                local ma = .
            }
            restore
            local lab
            if `first' local lab = cond("`y'" == "rate", "Vital-sign charting, entries per hour", "Discharged alive within 3 days, %")
            local first = 0
            local per = cond(`p' == 0, "Before implementation", cond(`p' == 1, "After implementation", "Difference-in-discontinuities"))
            fnum `mb' 2
            local a "`r(s)'"
            fnum `ma' 2
            local b "`r(s)'"
            fnum `est' 2
            local c "`r(s)'"
            fp `pv'
            prow "`lab'" "±`h'" "`per'" "`a'" "`b'" "`c'" "`r(s)'"
        }
    }
}
tsave "eTable 11"
