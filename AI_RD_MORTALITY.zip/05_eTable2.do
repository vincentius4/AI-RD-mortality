* eTable 2. Probability-scale estimates, robust bias-corrected inference, curvature and bias bandwidth (in-hospital death)
* Requires rdrobust (ssc install rdrobust)
use "$W/base.dta", clear
topen
* A and B: conventional and robust bias-corrected estimates, windows 5, 8 and 10
foreach h in 5 8 10 {
    foreach q in 1 0 {
        cap qui rdrobust death rv_dec if post == `q', c($CUT) h(`h') b(`h') p(1) kernel(triangular) covs($COVS) vce(cluster clust)
        local cl`q' = 100*e(tau_cl)
        local clse`q' = 100*e(se_tau_cl)
        local bc`q' = 100*e(tau_bc)
        local rbse`q' = 100*e(se_tau_rb)
    }
    local A`h'
    foreach q in 1 0 {
        fnum `cl`q'' 2
        local e "`r(s)'"
        fnum `clse`q'' 2
        local A`h' `"`A`h'' "`e' (`r(s)')""'
        fp `=2*normal(-abs(`cl`q''/`clse`q''))'
        local A`h' `"`A`h'' "`r(s)'""'
        fnum `bc`q'' 2
        local e "`r(s)'"
        fnum `rbse`q'' 2
        local A`h' `"`A`h'' "`e' (`r(s)')""'
        fp `=2*normal(-abs(`bc`q''/`rbse`q''))'
        local A`h' `"`A`h'' "`r(s)'""'
    }
    local B`h'
    local d = `cl1' - `cl0'
    local dse = sqrt(`clse1'^2 + `clse0'^2)
    fnum `d' 2
    local e "`r(s)'"
    fnum `dse' 2
    local B`h' `"`B`h'' "`e' (`r(s)')""'
    fp `=2*normal(-abs(`d'/`dse'))'
    local B`h' `"`B`h'' "`r(s)'""'
    local d = `bc1' - `bc0'
    local dse = sqrt(`rbse1'^2 + `rbse0'^2)
    fnum `d' 2
    local e "`r(s)'"
    fnum `dse' 2
    local B`h' `"`B`h'' "`e' (`r(s)')""'
    fp `=2*normal(-abs(`d'/`dse'))'
    local B`h' `"`B`h'' "`r(s)'""'
}
prow "A. In-hospital death: discontinuity at the threshold in each period on the probability scale (percentage points), under conventional and robust bias-corrected inference"
prow "" "After implementation, conventional" "After implementation, robust bias-corrected" "Before implementation, conventional" "Before implementation, robust bias-corrected"
prow "Window" "Estimate (SE)" "P value" "Estimate (SE)" "P value" "Estimate (SE)" "P value" "Estimate (SE)" "P value"
foreach h in 5 8 10 {
    prow "±`h'" `A`h''
}
prow "B. In-hospital death: difference-in-discontinuities (after minus before) on the probability scale (percentage points), under conventional and robust bias-corrected inference"
prow "" "Conventional" "Robust bias-corrected"
prow "Window" "Estimate (SE)" "P value" "Estimate (SE)" "P value"
foreach h in 5 8 10 {
    prow "±`h'" `B`h''
}

* C: local quadratic fit on each side of the threshold; relative curvature = |quadratic term| x h^2 / fitted level at the threshold
prow "C. In-hospital death: curvature of mortality in the score, by scale (local quadratic fits on each side of the threshold)"
prow "" "Quadratic term P value" ""
prow "Period" "Window" "Side" "Deaths" "Probability scale" "Logit scale" "Relative curvature"
foreach p in 1 0 {
    local first = 1
    foreach h in 5 8 10 {
        foreach side in 0 1 {
            preserve
            qui keep if post == `p' & abs(s) < `h' & D == `side'
            mkw `h' tri
            qui gen double s2 = s^2
            qui count if death == 1
            local dth = r(N)
            qui regress death s s2 [pw=kw], vce(cluster clust)
            seadj
            local pq1 = 2*normal(-abs(_b[s2]/(_se[s2]*r(adj))))
            local rel = abs(_b[s2])*`h'^2/abs(_b[_cons])
            qui logit death s s2 [pw=kw], vce(cluster clust) iter(100)
            seadj
            local pq2 = 2*normal(-abs(_b[s2]/(_se[s2]*r(adj))))
            restore
            local per
            if `first' local per = cond(`p' == 1, "After implementation", "Before implementation")
            local first = 0
            fp `pq1'
            local a "`r(s)'"
            fp `pq2'
            local b "`r(s)'"
            local sl = cond(`side' == 1, "At or above", "Below")
            fnum `rel' 2
            prow "`per'" "±`h'" "`sl'" "`dth'" "`a'" "`b'" "`r(s)'"
        }
    }
}

* D: bias bandwidth (after implementation)
prow "D. In-hospital death: sensitivity of robust bias-corrected inference to the bias bandwidth (after implementation)"
prow "" "Conventional" "Robust bias-corrected"
prow "Window" "Bias bandwidth" "Estimate, pp" "P value" "Estimate, pp" "Robust SE, pp" "Robust P value"
qui rdbwselect death rv_dec if post == 1, c($CUT) p(1) kernel(triangular) bwselect(mserd) covs($COVS) vce(cluster clust)
local bsel = e(b_mserd)
foreach h in 5 8 {
    foreach m in 1 1.5 2 0 {
        if `m' > 0 {
            local b = `h'*`m'
            local bl = cond(`m' == 1, "b = h", cond(`m' == 1.5, "b = 1.5h", "b = 2h"))
        }
        else {
            local b = `bsel'
            local bl = "b = data-driven (" + string(`bsel', "%4.2f") + ")"
        }
        qui rdrobust death rv_dec if post == 1, c($CUT) h(`h') b(`b') p(1) kernel(triangular) covs($COVS) vce(cluster clust)
        local t1 = 100*e(tau_cl)
        local p1 = e(pv_cl)
        local t2 = 100*e(tau_bc)
        local s2 = 100*e(se_tau_rb)
        local p2 = e(pv_rb)
        fnum `t1' 2
        local c1 "`r(s)'"
        fp `p1'
        local c2 "`r(s)'"
        fnum `t2' 2
        local c3 "`r(s)'"
        fnum `s2' 2
        local c4 "`r(s)'"
        fp `p2'
        prow "±`h'" "`bl'" "`c1'" "`c2'" "`c3'" "`c4'" "`r(s)'"
    }
}
qui rdrobust death rv_dec if post == 1, c($CUT) p(1) kernel(triangular) bwselect(mserd) covs($COVS) vce(cluster clust)
local hl = "±" + string(e(h_l), "%3.1f") + "a"
local bl = "both data-driven (b = " + string(e(b_l), "%4.2f") + ")"
local t1 = 100*e(tau_cl)
local p1 = e(pv_cl)
local t2 = 100*e(tau_bc)
local s2 = 100*e(se_tau_rb)
local p2 = e(pv_rb)
fnum `t1' 2
local c1 "`r(s)'"
fp `p1'
local c2 "`r(s)'"
fnum `t2' 2
local c3 "`r(s)'"
fnum `s2' 2
local c4 "`r(s)'"
fp `p2'
prow "`hl'" "`bl'" "`c1'" "`c2'" "`c3'" "`c4'" "`r(s)'"
tsave "eTable 2"
