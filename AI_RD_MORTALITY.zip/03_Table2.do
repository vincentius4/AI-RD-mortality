* Table 2. In-hospital death and death or ward cardiac arrest at the alert threshold
use "$W/base.dta", clear
topen
prow "Outcome and estimator" "Window, points" "Events/No." "Unadjusted OR (95% CI)" "Adjusted OR (95% CI)a" "P valueb" "Risk difference, percentage points (95% CI)c" "P valueb"
foreach y in death comp_gw {
    if "`y'" == "death" prow "In-hospital death (primary outcome)"
    else                prow "Death or ward cardiac arrest"
    local ests = cond("`y'" == "death", "dd post pre", "dd post")
    foreach e of local ests {
        foreach h in 5 8 {
            * unadjusted (hospital terms only) and adjusted odds ratios
            foreach cv in none adj {
                local co = cond("`cv'" == "none", "none", "")
                if "`e'" == "dd" didisc, h(`h') outcome(`y') covs(`co')
                else             srd, h(`h') post(`=cond("`e'" == "post", 1, 0)') outcome(`y') covs(`co')
                local p_`cv' = r(p)
                local evn "`r(ev)'/`r(n)'"
                orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' to
                local or_`cv' "`r(s)'"
            }
            fp `p_adj'
            local pa "`r(s)'"
            * risk difference at the threshold, percentage points (0.0 when |x| < 0.05)
            rdpp, h(`h') est(`e') outcome(`y')
            local rp = r(p)
            foreach x in rd lo hi {
                local r_`x' = r(`x')
            }
            foreach x in rd lo hi {
                local v = `r_`x''
                if abs(`v') < 0.05 local v = 0
                fnum `v' 1
                local s_`x' "`r(s)'"
            }
            local rdc "`s_rd' (`s_lo' to `s_hi')"
            fp `rp'
            local lab
            if `h' == 5 {
                if "`e'" == "dd"   local lab "Difference-in-discontinuities (primary)"
                if "`e'" == "post" local lab "Postimplementation discontinuity"
                if "`e'" == "pre"  local lab "Preimplementation discontinuityd"
            }
            prow "`lab'" "±`h'" "`evn'" "`or_none'" "`or_adj'" "`pa'" "`rdc'" "`r(s)'"
        }
    }
}
tsave "Table 2"
