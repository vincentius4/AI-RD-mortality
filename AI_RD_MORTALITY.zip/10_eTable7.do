* eTable 7. Every window from 1 to 10 points (internal value) with bias-aware inference; displayed integer score as the assignment variable
* Mata functions for the bias-aware (Armstrong-Kolesar) interval; defined here because rdrobust clears Mata
cap mata: mata drop wbias()
cap mata: mata drop hci()
mata:
real scalar wbias(string scalar xvars, string scalar wvar, string scalar svar, real scalar k)
{
    real matrix X, H, Hi
    real colvector w, s, b, p, W, A, u, f, sR, aR, sL, aL
    real scalar i, tot
    X = st_data(., tokens(xvars))
    X = X, J(rows(X), 1, 1)
    w = st_data(., wvar)
    s = st_data(., svar)
    b = st_matrix("e(b)")'
    p = invlogit(X*b)
    W = w :* p :* (1 :- p)
    H = quadcross(X, W, X) + 1e-6*I(cols(X))
    Hi = luinv(H)
    A = ((Hi*(X :* W)')[k, .])'
    tot = 0
    sR = select(s, s :>= 0)
    aR = select(A, s :>= 0)
    if (rows(sR) > 0) {
        u = rangen(0, max(sR), 401)
        f = J(401, 1, 0)
        for (i = 1; i <= 401; i++) f[i] = abs(sum(aR :* ((sR :- u[i]) :* ((sR :- u[i]) :> 0))))
        tot = tot + sum((u[|2 \ 401|] - u[|1 \ 400|]) :* (f[|2 \ 401|] + f[|1 \ 400|]))/2
    }
    sL = select(s, s :< 0)
    aL = select(A, s :< 0)
    if (rows(sL) > 0) {
        u = rangen(min(sL), 0, 401)
        f = J(401, 1, 0)
        for (i = 1; i <= 401; i++) f[i] = abs(sum(aL :* ((u[i] :- sL) :* ((u[i] :- sL) :> 0))))
        tot = tot + sum((u[|2 \ 401|] - u[|1 \ 400|]) :* (f[|2 \ 401|] + f[|1 \ 400|]))/2
    }
    return(tot)
}
void hci(real scalar est, real scalar se, real scalar B)
{
    real scalar t, z, lo, hi, mid, i
    t = B/se
    z = abs(est)/se
    lo = 0
    hi = 500
    for (i = 1; i <= 200; i++) {
        mid = (lo + hi)/2
        if (normal(mid - t) - normal(-mid - t) > 0.95) hi = mid
        else lo = mid
    }
    st_numscalar("r_hp", 1 - normal(z - t) + normal(-z - t))
}
end
* curvM: curvature bound M from the preimplementation data (local quadratic on the logit of displayed-score means)
cap program drop curvM
program define curvM, rclass
    preserve
    qui keep if post == 0 & s > -10 & s < 10
    qui gen double sr = round(s)
    collapse (mean) m = death, by(D sr)
    qui gen double g = min(max(m, 1e-4), 1 - 1e-4)
    qui gen double lg = ln(g/(1 - g))
    qui gen double sr2 = sr^2
    local M = 0
    foreach side in 0 1 {
        qui regress lg sr sr2 if D == `side'
        local M = max(`M', 2*abs(_b[sr2]))
    }
    restore
    return scalar M = `M'
end
* hp: bias-aware P value for the postimplementation discontinuity at window h
cap program drop hp
program define hp, rclass
    syntax , h(real) m(real)
    preserve
    qui keep if post == 1 & abs(s) < `h'
    mkw `h' tri
    qui gen double Ds = D*s
    qui logit death D s Ds hB hC $COVS [pw=kw], vce(cluster clust) iter(100)
    seadj
    local b = _b[D]
    local se = _se[D]*r(adj)
    mata: st_numscalar("r_Bu", wbias("D s Ds hB hC $COVS", "kw", "s", 1))
    mata: hci(`b', `se', `=`m'*scalar(r_Bu)')
    return scalar p = scalar(r_hp)
    restore
end

use "$W/base.dta", clear
curvM
local M = r(M)
topen
prow "A. Internal value as the assignment variable (threshold 89.5), every window from 1 to 10 points"
prow "" "Difference-in-discontinuities" "Single RD after implementation" "Single RD before implementation"
prow "Window" "Deaths (admissions)" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "Bias-aware P value" "OR (95% CI)" "P value"
forvalues h = 1/10 {
    trio, h(`h') outcome(death)
    foreach x in dd ddlo ddhi ddp ev n po polo pohi pop pr prlo prhi prp {
        local `x' = r(`x')
    }
    hp, h(`h') m(`M')
    fp `r(p)'
    local hpv "`r(s)'"
    orci `dd' `ddlo' `ddhi' -
    local a "`r(s)'"
    fp `ddp'
    local b "`r(s)'"
    orci `po' `polo' `pohi' -
    local c "`r(s)'"
    fp `pop'
    local d "`r(s)'"
    orci `pr' `prlo' `prhi' -
    local e "`r(s)'"
    fp `prp'
    prow "±`h'" "`ev' (`n')" "`a'" "`b'" "`c'" "`d'" "`hpv'" "`e'" "`r(s)'"
}
prow "B. Displayed integer score as the assignment variable (threshold 90)"
prow "" "Difference-in-discontinuities" "Single RD after implementation" "Single RD before implementation"
prow "Window" "Deaths (admissions)" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "OR" "P value"
replace s = rv - 90
replace D = (s >= 0)
foreach h in 3 5 8 10 {
    trio, h(`h') outcome(death)
    foreach x in dd ddlo ddhi ddp ev n po polo pohi pop pr prp {
        local `x' = r(`x')
    }
    orci `dd' `ddlo' `ddhi' -
    local a "`r(s)'"
    fp `ddp'
    local b "`r(s)'"
    orci `po' `polo' `pohi' -
    local c "`r(s)'"
    fp `pop'
    local d "`r(s)'"
    fnum `pr' 2
    local e "`r(s)'"
    fp `prp'
    prow "±`h'" "`ev' (`n')" "`a'" "`b'" "`c'" "`d'" "`e'" "`r(s)'"
}
tsave "eTable 7"
