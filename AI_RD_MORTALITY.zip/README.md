# DeepCARS: in-hospital mortality at the AI alert threshold

Stata 15 code that reproduces every table and figure of the paper. Data are not included; see the data sharing statement in the paper.

Requires `rdrobust` (eTable 2) and `rddensity` version 3.0 (eTable 4; install from github.com/rdpackages/rddensity, which includes `rddensity_fun.do`). Put the data files in this folder and run `do 00_master.do`, or run `01_data_and_programs.do` and then any single table file.

- `paper_data_v9.dta`: analysis data, one row per admission
- `process_flags_v1.dta`: treatments within 72 h of admission and in the 24 h before admission (eTables 9 and 12, Table 1)
- `process_t90_v2.dta`: process-of-care markers at the alert threshold, including the treatments on days 1-2 of Table 1 (Table 1, Figure 3, eTables 12 and 13)
- `process_t80_v1.dta` ... `process_t62_v1.dta`: the same markers at the placebo thresholds (eTable 13, eFigure 6)
- `rules_t90_v1.dta`: markers under the reference-time rules R0-R9 (eTable 14)
- `alt_assign_v1.dta`: alternative assignment variables (eTable 10)

| File | Output |
|---|---|
| 01_data_and_programs.do | landmark cohort, estimation and formatting programs |
| 02_Table1.do, 03_Table2.do | Table 1, Table 2 |
| 04_eTable1.do ... 17_eTable14.do | eTable 1 ... eTable 14 |
| 18_figures.do | Figure 1, Figure 2, eFigures 1-5 and 7 |
| 19_Figure3_eFigure6.do | Figure 3, eFigure 6 |

Each table file writes one sheet of `results/JAMA_tables.xlsx` with the cells as printed in the paper (table notes are not included); figures are written to `results/figures/`. Intermediate data sets are kept in `results/work/`.

`data_preparation/` holds the Python scripts that build the marker and treatment files from the hospital records (treatment and vital-sign records with time stamps, AI score records, admission times); definitions follow the eMethods.

Estimates in the paper were computed in Python 3.13; this Stata code reproduces them. Values that depend on the rdrobust version (robust standard errors of eTable 2) may differ in the last digit.
