* eTable 1. Admissions, deaths and cardiac arrests by hospital and period; derivation of the analysis sample
use "paper_data_v9.dta", clear
gen byte lm = (rv_dec < . & h_stay > 24)
topen
prow "" "Before implementation" "After implementation"
prow "Hospital" "Implementation date" "Population" "Admissions" "Deaths" "Cardiac arrests" "Admissions" "Deaths" "Cardiac arrests"
forvalues k = 1/3 {
    local hl : word `k' of A B C
    local dt : word `k' of "April 22, 2023" "October 5, 2023" "March 1, 2024"
    foreach pop in all landmark {
        local c
        foreach p in 0 1 {
            local cnd "hosp_num == `k' & treat == `p'"
            if "`pop'" == "landmark" local cnd "`cnd' & lm == 1"
            qui count if `cnd'
            fn `r(N)'
            local a "`r(s)'"
            qui count if `cnd' & death == 1
            fn `r(N)'
            local b "`r(s)'"
            qui count if `cnd' & arr_gw == 1
            local w = r(N)
            qui count if `cnd' & arr_any == 1
            local c `"`c' "`a'" "`b'" "`r(N)' (`w')""'
        }
        if "`pop'" == "all" prow "Hospital `hl'" "`dt'" "All admissions" `c'
        else                prow "" "" "Landmark cohort" `c'
    }
}
prow "Step" "All" "Before implementation" "After implementation"
gen double s = rv_dec - $CUT
local S1 "Admissions in the analysis data (adults on general wards, January 2022 to June 2025)|1"
local S2 "No AI score in the first 24 h (excluded)|rv_dec >= ."
local S3 "AI score in the first 24 h|rv_dec < ."
local S4 "Died or discharged before 24 h (excluded)|rv_dec < . & h_stay <= 24"
local S5 "Landmark cohort (in hospital at 24 h)|lm == 1"
local S6 "In-hospital deaths|lm == 1 & death == 1"
local S7 "Within ±5 points of the threshold (primary window)|lm == 1 & abs(s) < 5"
local S8 "In-hospital deaths|lm == 1 & abs(s) < 5 & death == 1"
local S9 "Within ±8 points of the threshold (secondary window)|lm == 1 & abs(s) < 8"
local S10 "In-hospital deaths|lm == 1 & abs(s) < 8 & death == 1"
forvalues r = 1/10 {
    tokenize "`S`r''", parse("|")
    local c
    foreach p in all 0 1 {
        if "`p'" == "all" qui count if `3'
        else              qui count if `3' & treat == `p'
        fn `r(N)'
        local c `"`c' "`r(s)'""'
    }
    prow "`1'" `c'
}
tsave "eTable 1"
