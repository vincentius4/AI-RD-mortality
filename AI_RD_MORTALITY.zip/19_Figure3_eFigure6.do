* Figure 3 (vital-sign measurement within 2 h and vasopressor or inotrope on days 1-2 at the alert threshold) and eFigure 6
* (the two Figure 3 markers at the alert threshold and the 10 placebo thresholds; hospitals A-C and B and C).
* Uses the programs of 01 and the placebo estimates saved by 16_eTable13.do.
* locfit: unadjusted local logistic fit on one side of the threshold (window 5); posts the fitted curve (80 points) to postfile `curve'
cap program drop locfit
program define locfit
    syntax , outcome(string) post(integer) side(integer) curve(string) panel(string)
    preserve
    qui keep if post == `post' & abs(s) < 5 & D == `side'
    mkw 5 tri
    qui logit `outcome' s [pw=kw], vce(cluster clust) iter(100)
    seadj
    local adj = r(adj)
    tempname V
    matrix `V' = e(V)*(`adj')^2
    local b1 = _b[s]
    local b0 = _b[_cons]
    forvalues j = 0/79 {
        if `side' == 0 local x = -5 + (5 - 0.001)*`j'/79
        else local x = 0 + (5 - 0.001)*`j'/79
        local eta = `b0' + `b1'*`x'
        local se = sqrt(`x'^2*`V'[1,1] + 2*`x'*`V'[1,2] + `V'[2,2])
        post `curve' ("`panel'") (`post') (`side') (`x' + $CUT + 0.5) (invlogit(`eta')) (invlogit(`eta' - 1.96*`se')) (invlogit(`eta' + 1.96*`se'))
    }
    restore
end
use "$W/base_pm.dta", clear
tempname CV
postfile `CV' str40 panel post side x p lo hi using "$W/F3_curves.dta", replace
foreach y in vital_any_A2h_any vaso_all_Bd12_any {
    foreach t in 0 1 {
        foreach sd in 0 1 {
            locfit, outcome(`y') post(`t') side(`sd') curve(`CV') panel(`y')
        }
    }
}
postclose `CV'
* observed proportions in 0.5-point bins
keep if abs(s) < 5
gen double bin = floor((rv_dec + 0.5)/0.5)*0.5 + 0.25
collapse (mean) vital_any_A2h_any vaso_all_Bd12_any, by(post bin)
save "$W/F3_bins.dta", replace
local k = 0
foreach y in vital_any_A2h_any vaso_all_Bd12_any {
    local ymax = cond("`y'" == "vital_any_A2h_any", 100, 25)
    local ylab = cond("`y'" == "vital_any_A2h_any", "Vital-sign measurement within 2 h, %", "Vasopressor or inotrope on days 1-2, %")
    foreach t in 0 1 {
        local k = `k' + 1
        local L : word `k' of A B C D
        local per = cond(`t' == 0, "Before implementation", "After implementation")
        local col = cond(`t' == 0, "gs9", "dkgreen")
        local fil = cond(`t' == 0, "gs13", "eltgreen")
        use "$W/F3_curves.dta", clear
        keep if panel == "`y'" & post == `t'
        foreach v in p lo hi {
            qui replace `v' = 100*`v'
        }
        append using "$W/F3_bins.dta"
        qui gen double pb = 100*`y' if bin < . & post == `t'
        twoway (rarea lo hi x if side == 0, color(`fil') lwidth(none)) (rarea lo hi x if side == 1, color(`fil') lwidth(none)) ///
            (line p x if side == 0, lcolor(`col') lwidth(medthick)) (line p x if side == 1, lcolor(`col') lwidth(medthick)) ///
            (scatter pb bin if post == `t', mcolor(`col') msize(small)), ///
            xline(90, lpattern(dash) lcolor(gs7)) ylabel(0(`=`ymax'/5')`ymax', angle(0)) xlabel(85(1)95) ///
            ytitle("`ylab'") xtitle("Highest AI score in first 24 h") title("`L'  `per'", position(11) size(medsmall)) legend(off) ///
            graphregion(color(white)) name(F3`L', replace) nodraw
    }
}
graph combine F3A F3B F3C F3D, cols(2) ysize(6) xsize(7) graphregion(color(white))
graph export "results/figures/Figure3.png", replace width(2100)

* eFigure 6: estimates at the alert threshold (90) and the placebo thresholds 62-80
tempname TH
postfile `TH' cut str32 spec str4 hosp dd ddlo ddhi po polo pohi using "$W/eF6_true.dta", replace
foreach hs in ABC BC {
    foreach y in vital_any_A2h_any vaso_all_Bd12_any {
        use "$W/base_pm.dta", clear
        if "`hs'" == "BC" qui keep if hB == 1 | hC == 1
        trio, h(5) outcome(`y')
        post `TH' (90) ("`y'") ("`hs'") (r(dd)) (r(ddlo)) (r(ddhi)) (r(po)) (r(polo)) (r(pohi))
    }
}
postclose `TH'
use "$W/placebo_markers.dta", clear
keep if inlist(spec, "vital_any_A2h_any", "vaso_all_Bd12_any")
gen str4 hosp = "ABC"
append using "$W/placebo_markers_BC.dta"
replace hosp = "BC" if hosp == ""
append using "$W/eF6_true.dta"
gen x = (cut - 60)/2
replace x = 11 if cut == 90
gen x1 = x - 0.15
gen x2 = x + 0.15
local k = 0
foreach hs in ABC BC {
    foreach y in vital_any_A2h_any vaso_all_Bd12_any {
        local k = `k' + 1
        local L : word `k' of A B C D
        local ttl = cond("`y'" == "vital_any_A2h_any", "Vital-sign measurement within 2 h", "Vasopressor or inotrope on days 1-2")
        local hl = cond("`hs'" == "ABC", "hospitals A-C", "hospitals B and C")
        twoway (rcap ddlo ddhi x1 if spec == "`y'" & hosp == "`hs'", lcolor(navy)) (scatter dd x1 if spec == "`y'" & hosp == "`hs'", mcolor(navy) msymbol(O)) ///
            (rcap polo pohi x2 if spec == "`y'" & hosp == "`hs'", lcolor(dkgreen)) (scatter po x2 if spec == "`y'" & hosp == "`hs'", mcolor(dkgreen) msymbol(O)), ///
            yscale(log range(0.1 40)) ylabel(0.1 0.25 0.5 1 2 5 10 20, angle(0)) yline(1, lcolor(gs8)) ///
            xlabel(1 "62" 2 "64" 3 "66" 4 "68" 5 "70" 6 "72" 7 "74" 8 "76" 9 "78" 10 "80" 11 "90") ///
            xtitle("Threshold (displayed score)", size(small)) ytitle("OR (95% CI), log scale", size(small)) ///
            title("`L'  `ttl'" "`hl'", position(11) size(small)) legend(order(2 "Difference-in-discontinuities" 4 "Postimplementation discontinuity") rows(2) size(vsmall)) ///
            graphregion(color(white)) name(EF6`L', replace) nodraw
    }
}
graph combine EF6A EF6B EF6C EF6D, cols(2) ysize(7) xsize(8) graphregion(color(white))
graph export "results/figures/eFigure6.png", replace width(2400)
