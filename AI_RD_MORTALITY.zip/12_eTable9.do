* eTable 9. Treatments recorded in the 24 h before admission at the threshold (window 5), and in-hospital death adjusted for them
use "$W/base.dta", clear
merge 1:1 adm_id using "process_flags_v1.dta", keep(master match) nogen
save "$W/base_flags.dta", replace
topen
prow "Outcome (hospitals)" "Before implementation, No. (%)" "After implementation, No. (%)" "DiD-RD" "Post-RD" "Pre-RD"
prow "" "Below" "Above" "Below" "Above" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "OR (95% CI)" "P value"
prow_mark b_any  ABC "Any measured treatment (A-C)"   "$W/base_flags.dta"
prow_mark b_abx  AC  "Intravenous antibiotic (A, C)"  "$W/base_flags.dta"
prow_mark b_bc   ABC "Blood culture (A-C)"            "$W/base_flags.dta" na
prow_mark b_lac  BC  "Lactate measurement (B, C)"     "$W/base_flags.dta" na
prow_mark b_o2   ABC "Oxygen escalation (A-C)"        "$W/base_flags.dta"
prow_mark b_vaso ABC "Vasopressor or inotrope (A-C)"  "$W/base_flags.dta"
prow "Window" "Adjustment (treatment in the 24 h before admission)" "OR (95% CI)" "P value"
use "$W/base_flags.dta", clear
foreach h in 5 8 {
    foreach a in none b_abx b_bc b_lac b_o2 b_vaso all {
        if "`a'" == "none" local c "$COVS"
        else if "`a'" == "all" local c "$COVS b_abx b_bc b_lac b_o2 b_vaso"
        else local c "$COVS `a'"
        if "`a'" == "none"   local lab "None (primary analysis)"
        if "`a'" == "b_abx"  local lab "+ intravenous antibiotic"
        if "`a'" == "b_bc"   local lab "+ blood culture"
        if "`a'" == "b_lac"  local lab "+ lactate measurement"
        if "`a'" == "b_o2"   local lab "+ oxygen escalation"
        if "`a'" == "b_vaso" local lab "+ vasopressor or inotrope"
        if "`a'" == "all"    local lab "+ all five"
        didisc, h(`h') covs(`c')
        local p = r(p)
        orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' to
        local o "`r(s)'"
        fp `p'
        prow "Window ±`h'" "`lab'" "`o'" "`r(s)'"
    }
}
tsave "eTable 9"
