* Table 1. Characteristics of admissions within 5 points of the alert threshold
use "$W/base.dta", clear
merge 1:1 adm_id using "process_flags_v1.dta", keep(master match) keepusing(b_any) nogen
merge 1:1 adm_id using "process_t90_v2.dta", keep(master match) keepusing(vaso_all_Bd12_any o2_escalation_Bd12_any blood_culture_Bd12_any abx_iv_Bd12_any) nogen
keep if abs(s) < 5
gen byte female = 1 - male
gen byte hA = (hB == 0 & hC == 0)
local G1 "post == 0 & D == 0"
local G2 "post == 0 & D == 1"
local G3 "post == 1 & D == 0"
local G4 "post == 1 & D == 1"
topen
prow "Characteristic" "Before implementation, No. (%)a" "After implementation, No. (%)a"
local c
forvalues g = 1/4 {
    qui count if `G`g''
    local lab = cond(inlist(`g', 1, 3), "Score 85-89", "Score 90-94")
    local c `"`c' "`lab' (n = `r(N)')""'
}
prow "" `c'
prow "Characteristics at admission"
local R1 "Age, median (IQR), y|m0|age"
local R2 "Female sex|b|female"
local R3 "Charlson comorbidity index, mean (SD)|sd|cci"
local R4 "Hypertension|b|htn"
local R5 "SOFA score, mean (SD)|sd|sofa"
local R6 "Surgical specialty|b|surgical_dept"
local R7 "Hospital|h|"
local R8 "A|b|hA"
local R9 "B|b|hB"
local R10 "C|b|hC"
local R11 "Highest AI score in the first 24 h, median (IQR)|m1|rv_dec"
local R12 "Any measured treatment in the 24 h before admissionb|b|b_any"
local R13 "Treatment on days 1-2 after admissionc|h|"
local R14 "Vasopressor or inotrope|b|vaso_all_Bd12_any"
local R15 "Oxygen escalation|b|o2_escalation_Bd12_any"
local R16 "Blood culture|b|blood_culture_Bd12_any"
local R17 "Intravenous antibiotic|b|abx_iv_Bd12_any"
forvalues r = 1/17 {
    tokenize "`R`r''", parse("|")
    local lab "`1'"
    local kind "`3'"
    local var "`5'"
    if "`kind'" == "h" {
        prow "`lab'"
        continue
    }
    local c
    forvalues g = 1/4 {
        if "`kind'" == "b"       npc `var' "`G`g''"
        else if "`kind'" == "sd" msd `var' "`G`g''"
        else                     miqr `var' "`G`g''" `=cond("`kind'" == "m0", 0, 1)'
        local c `"`c' "`r(s)'""'
    }
    prow "`lab'" `c'
}
tsave "Table 1"
