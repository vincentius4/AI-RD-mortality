* Data and programs used by every table and figure file
* Output: results/JAMA_tables.xlsx (one sheet per manuscript table, cells as printed) and results/figures/ (figures)
version 15
clear all
set more off
set seed 7
cap mkdir results
cap mkdir results/work
cap mkdir results/figures
cap log close
log using "results/run_log.log", replace text
global OUTX "results/JAMA_tables.xlsx"
global W    "results/work"
global COVS age_z male cci htn sofa surgical_dept summer fall winter
global CUT  89.5

* Landmark cohort: AI score in the first 24 h and in hospital at 24 h
use "paper_data_v9.dta", clear
keep if rv_dec < .
keep if h_stay > 24
gen double s    = rv_dec - $CUT
gen byte   D    = (s >= 0)
gen byte   post = treat
gen int    disp = round(rv_dec)
gen byte   arr_nondnr = (arr_any == 1) | (death == 1 & dnr_case == 0)
gen byte   disc3 = (total_los <= 3 & death == 0)
save "$W/base.dta", replace

* ---------- estimation programs ----------
* seadj: small-sample factor applied to cluster-robust standard errors (as in the Python code that produced the paper)
program define seadj, rclass
    local adj = 1
    if "`e(cmd)'" == "regress" {
        if "`e(clustvar)'" != "" local adj = sqrt((e(N_clust)-1)/e(N_clust) * (e(N)-e(rank))/(e(N)-1))
        else local adj = sqrt((e(N)-e(rank))/e(N))
    }
    else {
        if "`e(clustvar)'" != "" local adj = sqrt((e(N_clust)-1)/e(N_clust))
        else local adj = sqrt((e(N)-1)/e(N))
    }
    return scalar adj = `adj'
end

* mkw: kernel weight within window h (triangular unless stated)
program define mkw
    args h kern
    cap drop kw
    if "`kern'" == "uni"      gen double kw = 1
    else if "`kern'" == "epa" gen double kw = max(0, 0.75*(1 - (s/`h')^2))
    else                      gen double kw = max(0, 1 - abs(s)/`h')
end

* didisc: difference-in-discontinuities (pooled local logistic model; coefficient on post x above threshold)
program define didisc, rclass
    syntax , h(real) [outcome(string) covs(string)]
    if "`outcome'" == "" local outcome death
    if "`covs'" == ""    local covs $COVS
    if "`covs'" == "none" local covs
    preserve
    qui keep if abs(s) < `h'
    mkw `h' tri
    qui gen double Ds = D*s
    qui gen double pD = post*D
    qui gen double ps = post*s
    qui gen double pDs = post*D*s
    qui gen double hB_post = hB*post
    qui gen double hC_post = hC*post
    qui gen double hB_D = hB*D
    qui gen double hC_D = hC*D
    qui count if `outcome' == 1
    local ev = r(N)
    qui count
    local n = r(N)
    cap qui logit `outcome' D s Ds post pD ps pDs hB hC hB_post hC_post hB_D hC_D `covs' [pw=kw], vce(cluster clust) iter(100)
    if _rc == 0 & `ev' >= 15 {
        seadj
        return scalar b = _b[pD]
        return scalar se = _se[pD]*r(adj)
        return scalar p = 2*normal(-abs(_b[pD]/(_se[pD]*r(adj))))
    }
    else {
        return scalar b = .
        return scalar se = .
        return scalar p = .
    }
    return scalar ev = `ev'
    return scalar n = `n'
    restore
end

* srd: single-period regression discontinuity (post = 1 after, 0 before implementation)
program define srd, rclass
    syntax , h(real) post(integer) [outcome(string) covs(string)]
    if "`outcome'" == "" local outcome death
    if "`covs'" == ""    local covs $COVS
    if "`covs'" == "none" local covs
    preserve
    qui keep if post == `post' & abs(s) < `h'
    mkw `h' tri
    qui gen double Ds = D*s
    qui count if `outcome' == 1
    local ev = r(N)
    qui count
    local n = r(N)
    cap qui logit `outcome' D s Ds hB hC `covs' [pw=kw], vce(cluster clust) iter(100)
    if _rc == 0 & `ev' >= 8 {
        seadj
        return scalar b = _b[D]
        return scalar se = _se[D]*r(adj)
        return scalar p = 2*normal(-abs(_b[D]/(_se[D]*r(adj))))
    }
    else {
        return scalar b = .
        return scalar se = .
        return scalar p = .
    }
    return scalar ev = `ev'
    return scalar n = `n'
    restore
end

* trio: difference-in-discontinuities and the two single-period discontinuities for one outcome (odds ratios, 95% CI with 1.96)
program define trio, rclass
    syntax , h(real) outcome(string) [covs(string)]
    didisc, h(`h') outcome(`outcome') covs(`covs')
    local dd = exp(r(b))
    local ddlo = exp(r(b) - 1.96*r(se))
    local ddhi = exp(r(b) + 1.96*r(se))
    local ddp = r(p)
    local ev = r(ev)
    local n = r(n)
    srd, h(`h') post(1) outcome(`outcome') covs(`covs')
    local po = exp(r(b))
    local polo = exp(r(b) - 1.96*r(se))
    local pohi = exp(r(b) + 1.96*r(se))
    local pop = r(p)
    local evpo = r(ev)
    local npo = r(n)
    srd, h(`h') post(0) outcome(`outcome') covs(`covs')
    local pr = exp(r(b))
    local prlo = exp(r(b) - 1.96*r(se))
    local prhi = exp(r(b) + 1.96*r(se))
    local prp = r(p)
    local evpr = r(ev)
    local npr = r(n)
    foreach x in dd ddlo ddhi ddp ev n po polo pohi pop evpo npo pr prlo prhi prp evpr npr {
        return scalar `x' = ``x''
    }
end

* rdpp: model-based risk difference at the threshold (percentage points, delta method; est = dd, post or pre)
program define rdpp, rclass
    syntax , h(real) est(string) [outcome(string)]
    if "`outcome'" == "" local outcome death
    preserve
    qui keep if abs(s) < `h'
    if "`est'" == "post" qui keep if post == 1
    if "`est'" == "pre"  qui keep if post == 0
    mkw `h' tri
    qui gen double Ds = D*s
    if "`est'" == "dd" {
        qui gen double pD = post*D
        qui gen double ps = post*s
        qui gen double pDs = post*D*s
        qui gen double hB_post = hB*post
        qui gen double hC_post = hC*post
        qui gen double hB_D = hB*D
        qui gen double hC_D = hC*D
        qui logit `outcome' D s Ds post pD ps pDs hB hC hB_post hC_post hB_D hC_D $COVS [pw=kw], vce(cluster clust) iter(100)
        seadj
        local adj = r(adj)
        * post-implementation admissions at the threshold (D = 1, s = 0); remove only the period-by-threshold term
        qui replace hB_D = hB
        qui replace hC_D = hC
        qui margins if post == 1, at(D = 1 s = 0 Ds = 0 post = 1 pD = 1 ps = 0 pDs = 0) ///
            expression(invlogit(predict(xb)) - invlogit(predict(xb) - _b[pD]))
    }
    else {
        qui logit `outcome' D s Ds hB hC $COVS [pw=kw], vce(cluster clust) iter(100)
        seadj
        local adj = r(adj)
        qui margins, at(D = 1 s = 0 Ds = 0) expression(invlogit(predict(xb)) - invlogit(predict(xb) - _b[D]))
    }
    tempname B V
    matrix `B' = r(b)
    matrix `V' = r(V)
    local rd = `B'[1,1]
    local se = sqrt(`V'[1,1])*`adj'
    return scalar rd = 100*`rd'
    return scalar lo = 100*(`rd' - 1.959964*`se')
    return scalar hi = 100*(`rd' + 1.959964*`se')
    return scalar p = 2*normal(-abs(`rd'/`se'))
    restore
end

* ---------- formatting programs (JAMA style as printed) ----------
* fnum: x with dp decimals, minus sign as in the paper
program define fnum, rclass
    args x dp
    if `x' >= . {
        return local s "NA"
        exit
    }
    local s = strtrim(string(`x', "%20.`dp'f"))
    if substr("`s'", 1, 1) == "-" local s = "−" + substr("`s'", 2, .)
    return local s "`s'"
end
* fp: P value (<.001; 3 decimals below .01; otherwise 2 decimals)
program define fp, rclass
    args p
    if `p' >= . {
        return local s "NA"
        exit
    }
    if `p' < 0.001 local s "<.001"
    else {
        if `p' < 0.01 {
            local s = string(`p', "%5.3f")
            if "`s'" == "0.010" local s "0.01"
        }
        else local s = string(`p', "%4.2f")
        local s = substr("`s'", 2, .)
    }
    return local s "`s'"
end
* fn: count, space as thousands separator from 10 000
program define fn, rclass
    args x
    if `x' >= 10000 local s = subinstr(strtrim(string(`x', "%15.0fc")), ",", " ", .)
    else local s = string(`x', "%15.0f")
    return local s "`s'"
end
* orci: OR (lo to hi) or OR (lo-hi); sep = to or dash
program define orci, rclass
    args or lo hi sep
    if `or' >= . {
        return local s "NA"
        exit
    }
    local a = strtrim(string(`or', "%20.2f"))
    local b = strtrim(string(`lo', "%20.2f"))
    local c = strtrim(string(`hi', "%20.2f"))
    if "`sep'" == "to" return local s "`a' (`b' to `c')"
    else return local s "`a' (`b'-`c')"
end
* npc: n (%) of v == 1 among observations meeting cond
program define npc, rclass
    args v cond
    qui count if `cond'
    local n = r(N)
    qui count if `cond' & `v' == 1
    local k = r(N)
    fn `k'
    return local s = "`r(s)' (" + string(100*`k'/`n', "%4.1f") + ")"
end
* miqr: median (IQR) with linear interpolation between order statistics; dp decimals
program define miqr, rclass
    args v cond dp
    preserve
    qui keep if `cond' & `v' < .
    sort `v'
    local n = _N
    foreach q in 25 50 75 {
        local pos = (`n' - 1)*`q'/100 + 1
        local lo = floor(`pos')
        local hi = ceil(`pos')
        local q`q' = `v'[`lo'] + (`pos' - `lo')*(`v'[`hi'] - `v'[`lo'])
    }
    restore
    return local s = string(`q50', "%9.`dp'f") + " (" + string(`q25', "%9.`dp'f") + " to " + string(`q75', "%9.`dp'f") + ")"
end
* msd: mean (SD), 2 decimals
program define msd, rclass
    args v cond
    qui su `v' if `cond'
    return local s = string(r(mean), "%9.2f") + " (" + string(r(sd), "%9.2f") + ")"
end

* ---------- table writer: one row of up to 12 cells per call; tsave writes the sheet ----------
program define topen
    global TBL tbl_handle
    cap postclose $TBL
    postfile $TBL str244(c1 c2 c3 c4 c5 c6 c7 c8 c9 c10 c11 c12) using "$W/_table.dta", replace
end
program define prow
    local nw : word count `0'
    local args
    forvalues k = 1/12 {
        local c
        if `k' <= `nw' local c : word `k' of `0'
        local args `"`args' (`"`c'"')"'
    }
    post $TBL `args'
end
program define tsave
    args sheet
    postclose $TBL
    preserve
    use "$W/_table.dta", clear
    export excel using "$OUTX", sheet("`sheet'") sheetreplace
    restore
end
* prow_mark: one row of eTables 9 and 12 for indicator y in data file `data' (hospitals ABC, AC or BC; window 5):
* n (%) below and above the threshold in each period, then the three estimates with 95% CIs and P values
* (na: estimates shown as NA, for treatments rarely recorded before admission, as in the paper)
program define prow_mark
    args y hs lab data na
    use "`data'", clear
    if "`hs'" == "AC" qui keep if hB == 0
    if "`hs'" == "BC" qui keep if hB == 1 | hC == 1
    local c
    foreach p in 0 1 {
        foreach sd in 0 1 {
            npc `y' "post == `p' & D == `sd' & abs(s) < 5"
            local c `"`c' "`r(s)'""'
        }
    }
    trio, h(5) outcome(`y')
    foreach x in dd ddlo ddhi ddp po polo pohi pop pr prlo prhi prp {
        local `x' = r(`x')
    }
    foreach k in dd po pr {
        if "`na'" == "na" {
            local c `"`c' "NA" "NA""'
            continue
        }
        orci ``k'' ``k'lo' ``k'hi' to
        local c `"`c' "`r(s)'""'
        fp ``k'p'
        local c `"`c' "`r(s)'""'
    }
    prow "`lab'" `c'
end
