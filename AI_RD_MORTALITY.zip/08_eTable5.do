* eTable 5. Placebo thresholds, negative-control assignment variable (NEWS) and full-range placebo scan
use "$W/base.dta", clear
topen
* A: placebo thresholds on the AI score scale, admissions on one side of the true threshold only (window 5)
prow "A. Placebo thresholds on the AI score scale (difference-in-discontinuities, ±5)"
prow "Placebo threshold (displayed score)" "Deaths" "OR (95% CI)" "P value"
foreach c in 80 83 85 87 92 94 96 90 {
    preserve
    if `c' < 90 qui keep if rv_dec < $CUT
    if `c' > 90 qui keep if rv_dec >= $CUT
    qui replace s = rv_dec - (`c' - 0.5)
    qui replace D = (s >= 0)
    didisc, h(5)
    local ev = r(ev)
    local p = r(p)
    orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' -
    local o "`r(s)'"
    fp `p'
    prow "`c'" "`ev'" "`o'" "`r(s)'"
    restore
}
* B: National Early Warning Score as the assignment variable
prow "B. Negative-control assignment variable: National Early Warning Score (difference-in-discontinuities)"
prow "NEWS threshold" "Window" "Deaths" "OR (95% CI)" "P value"
foreach c in 5 6 7 {
    foreach h in 3 4 {
        preserve
        qui replace s = rv_news - `c'
        qui replace D = (s >= 0)
        didisc, h(`h')
        local ev = r(ev)
        local p = r(p)
        orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' -
        local o "`r(s)'"
        fp `p'
        prow "`c'" "`h'" "`ev'" "`o'" "`r(s)'"
        restore
    }
}
* C: every integer threshold from 45 to 99; estimable when both periods have at least 120 admissions, 6 deaths and 15%-85% on each side
tempname SC
postfile `SC' h displayed dd_or dd_p using "$W/scan.dta", replace
foreach hh in 3 5 10 {
    forvalues c = 45/99 {
        preserve
        if `c' < 90 qui keep if rv_dec < $CUT
        if `c' > 90 qui keep if rv_dec >= $CUT
        qui replace s = rv_dec - (`c' - 0.5)
        qui replace D = (s >= 0)
        local ok = 1
        foreach p in 0 1 {
            qui count if post == `p' & abs(s) < `hh'
            local nn = r(N)
            qui count if post == `p' & abs(s) < `hh' & death == 1
            local ee = r(N)
            qui count if post == `p' & abs(s) < `hh' & D == 1
            local sh = cond(`nn' > 0, r(N)/`nn', 0)
            if `nn' < 120 | `ee' < 6 | `sh' < 0.15 | `sh' > 0.85 local ok = 0
        }
        if `ok' {
            didisc, h(`hh')
            if r(b) < . post `SC' (`hh') (`c') (exp(r(b))) (r(p))
        }
        restore
    }
}
postclose `SC'
prow "C. Full-range placebo scan: every integer threshold from 45 to 99"
prow "" "Placebo thresholds" ""
prow "Window" "True threshold, OR" "P value" "Estimable, n" "P < .05, n" "More extreme than true threshold, n" "Randomization P value" "Range of ORs"
preserve
use "$W/scan.dta", clear
gen double absl = abs(ln(dd_or))
foreach hh in 3 5 10 {
    qui su absl if displayed == 90 & h == `hh'
    local tr = r(mean)
    qui su dd_or if displayed == 90 & h == `hh'
    local o90 = r(mean)
    qui su dd_p if displayed == 90 & h == `hh'
    local p90 = r(mean)
    qui count if displayed != 90 & h == `hh'
    local npl = r(N)
    qui count if displayed != 90 & h == `hh' & dd_p < 0.05
    local nsig = r(N)
    qui count if displayed != 90 & h == `hh' & absl >= `tr' - 1e-12
    local nex = r(N)
    qui su dd_or if displayed != 90 & h == `hh'
    local rng = string(r(min), "%4.2f") + "-" + string(r(max), "%4.2f")
    fnum `o90' 2
    local a "`r(s)'"
    fp `p90'
    local b "`r(s)'"
    fp `=(1 + `nex')/(`npl' + 1)'
    prow "±`hh'" "`a'" "`b'" "`npl'" "`nsig'" "`nex'" "`r(s)'" "`rng'"
}
restore
tsave "eTable 5"
