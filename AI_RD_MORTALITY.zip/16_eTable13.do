* eTable 13. Process-of-care markers at the alert threshold: specifications (part 1), window 8, linear probability models and
* placebo thresholds (part 2), hospital-level estimates (part 3). Also saves the placebo-threshold estimates used by eFigure 6.
* lpm: the primary design as a linear probability model (percentage points); est = dd or post
cap program drop lpm
program define lpm, rclass
    syntax , h(real) outcome(string) est(string)
    preserve
    qui keep if abs(s) < `h'
    if "`est'" == "post" qui keep if post == 1
    mkw `h' tri
    qui gen double Ds = D*s
    if "`est'" == "dd" {
        qui gen double pD = post*D
        qui gen double ps = post*s
        qui gen double pDs = post*D*s
        qui gen double hB_post = hB*post
        qui gen double hC_post = hC*post
        qui gen double hB_D = hB*D
        qui gen double hC_D = hC*D
        qui regress `outcome' D s Ds post pD ps pDs hB hC hB_post hC_post hB_D hC_D $COVS [pw=kw], vce(cluster clust)
        local b = _b[pD]
        local se = _se[pD]
    }
    else {
        qui regress `outcome' D s Ds hB hC $COVS [pw=kw], vce(cluster clust)
        local b = _b[D]
        local se = _se[D]
    }
    seadj
    local se = `se'*r(adj)
    return scalar pp = 100*`b'
    return scalar lo = 100*(`b' - 1.96*`se')
    return scalar hi = 100*(`b' + 1.96*`se')
    return scalar p = 2*normal(-abs(`b'/`se'))
    restore
end
local MARK "vital_any_A1h_any vital_any_A2h_any vital_any_A3h_any vaso_all_Bd1_any vaso_all_Bd12_any o2_escalation_A1h_new o2_escalation_A24h_new o2_escalation_A72h_new blood_culture_Bd01_any"
local L_vital_any_A1h_any "VS ≤1 h"
local L_vital_any_A2h_any "VS ≤2 h (Figure 3)"
local L_vital_any_A3h_any "VS ≤3 h"
local L_vaso_all_Bd1_any "VI, day 1"
local L_vaso_all_Bd12_any "VI, days 1-2 (Figure 3)"
local L_o2_escalation_A1h_new "O2 ≤1 h, new"
local L_o2_escalation_A24h_new "O2 ≤24 h, new"
local L_o2_escalation_A72h_new "O2 ≤72 h, new"
local L_blood_culture_Bd01_any "BC, days 0-1"

* placebo thresholds (displayed scores 80, 78, ..., 62): markers re-timed at each threshold; specifications with at least 15 events and
* 15 non-events within 5 points (all hospitals); the two Figure 3 markers also at hospitals B and C (eFigure 6)
tempname PP PB
postfile `PP' cut str32 spec dd ddlo ddhi ddp po polo pohi pop using "$W/placebo_markers.dta", replace
postfile `PB' cut str32 spec dd ddlo ddhi ddp po polo pohi pop using "$W/placebo_markers_BC.dta", replace
foreach c in 80 78 76 74 72 70 68 66 64 62 {
    use "$W/base.dta", clear
    qui replace s = rv_dec - (`c' - 0.5)
    qui replace D = (s >= 0)
    merge 1:1 adm_id using "process_t`c'_v1.dta", keep(match) nogen
    qui keep if abs(s) < 5
    save "$W/base_plac.dta", replace
    foreach y of local MARK {
        qui count if `y' == 1
        local ev = r(N)
        qui count
        if `ev' >= 15 & r(N) - `ev' >= 15 {
            didisc, h(5) outcome(`y')
            local dd = exp(r(b))
            local ddlo = exp(r(b) - 1.96*r(se))
            local ddhi = exp(r(b) + 1.96*r(se))
            local ddp = r(p)
            srd, h(5) post(1) outcome(`y')
            post `PP' (`c') ("`y'") (`dd') (`ddlo') (`ddhi') (`ddp') (exp(r(b))) (exp(r(b) - 1.96*r(se))) (exp(r(b) + 1.96*r(se))) (r(p))
        }
    }
    qui keep if hB == 1 | hC == 1
    foreach y in vital_any_A2h_any vaso_all_Bd12_any {
        didisc, h(5) outcome(`y')
        local dd = exp(r(b))
        local ddlo = exp(r(b) - 1.96*r(se))
        local ddhi = exp(r(b) + 1.96*r(se))
        local ddp = r(p)
        srd, h(5) post(1) outcome(`y')
        post `PB' (`c') ("`y'") (`dd') (`ddlo') (`ddhi') (`ddp') (exp(r(b))) (exp(r(b) - 1.96*r(se))) (exp(r(b) + 1.96*r(se))) (r(p))
    }
}
postclose `PP'
postclose `PB'
use "$W/placebo_markers.dta", clear
gen byte hit = (dd > 1 & ddp < .05)
gen byte one = 1
collapse (sum) n_eval = one n_hit = hit, by(spec)
foreach i of numlist 1/`=_N' {
    local PL_`=spec[`i']' = string(n_hit[`i']) + "/" + string(n_eval[`i'])
}

use "process_t90_v2.dta", clear
merge 1:1 adm_id using "$W/base.dta", keep(match) nogen
save "$W/base_pm.dta", replace
topen
* part 1: window 5, hospitals A-C and B-C
prow "Marker (hospitals)" "Events/No." "DiD-RD" "Post-RD" "Pre-RD"
prow "" "" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "OR" "P value"
foreach y of local MARK {
    foreach hs in ABC BC {
        use "$W/base_pm.dta", clear
        if "`hs'" == "BC" qui keep if hB == 1 | hC == 1
        trio, h(5) outcome(`y')
        foreach x in dd ddlo ddhi ddp ev n po polo pohi pop pr prp {
            local `x' = r(`x')
        }
        orci `dd' `ddlo' `ddhi' to
        local a "`r(s)'"
        fp `ddp'
        local b "`r(s)'"
        orci `po' `polo' `pohi' to
        local c "`r(s)'"
        fp `pop'
        local d "`r(s)'"
        fnum `pr' 2
        local e "`r(s)'"
        fp `prp'
        local hl = cond("`hs'" == "ABC", "(A-C)", "(B, C)")
        prow "`L_`y'' `hl'" "`ev'/`n'" "`a'" "`b'" "`c'" "`d'" "`e'" "`r(s)'"
    }
}
* part 2: window 8, linear probability models (window 5) and placebo thresholds; hospitals A-C
prow "Marker" "DiD-RD, ±8" "Post-RD, ±8" "DiD-RD, linear, percentage points" "Post-RD, linear, percentage points" "Placebo thresholds"
prow "" "OR (95% CI)" "P value" "OR" "P value" "Difference (95% CI)" "P value" "Difference" "P value" "Significant, No./10"
foreach y of local MARK {
    use "$W/base_pm.dta", clear
    trio, h(8) outcome(`y')
    foreach x in dd ddlo ddhi ddp po pop {
        local `x' = r(`x')
    }
    lpm, h(5) outcome(`y') est(dd)
    foreach x in pp lo hi p {
        local l_`x' = r(`x')
    }
    lpm, h(5) outcome(`y') est(post)
    foreach x in pp p {
        local m_`x' = r(`x')
    }
    orci `dd' `ddlo' `ddhi' to
    local a "`r(s)'"
    fp `ddp'
    local b "`r(s)'"
    fnum `po' 2
    local c "`r(s)'"
    fp `pop'
    local d "`r(s)'"
    fnum `l_pp' 1
    local e1 "`r(s)'"
    fnum `l_lo' 1
    local e2 "`r(s)'"
    fnum `l_hi' 1
    local e "`e1' (`e2' to `r(s)')"
    fp `l_p'
    local f "`r(s)'"
    fnum `m_pp' 1
    local g "`r(s)'"
    fp `m_p'
    prow "`L_`y''" "`a'" "`b'" "`c'" "`d'" "`e'" "`f'" "`g'" "`r(s)'" "`PL_`y''"
}
* part 3: hospital-level difference-in-discontinuities (window 5)
prow "Marker" "DiD-RD, OR (95% CI); P value"
prow "" "Hospital A" "Hospital B" "Hospital C"
foreach y in vital_any_A1h_any vital_any_A2h_any vaso_all_Bd1_any vaso_all_Bd12_any o2_escalation_A1h_new {
    local c
    forvalues k = 1/3 {
        use "$W/base_pm.dta", clear
        if `k' == 1 qui keep if hB == 0 & hC == 0
        if `k' == 2 qui keep if hB == 1
        if `k' == 3 qui keep if hC == 1
        didisc, h(5) outcome(`y')
        local p = r(p)
        orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' to
        local o "`r(s)'"
        fp `p'
        local c `"`c' "`o'; P = `r(s)'""'
    }
    prow "`L_`y''" `c'
}
tsave "eTable 13"
