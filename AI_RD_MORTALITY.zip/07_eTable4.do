* eTable 4. Density, covariate continuity, covariate discontinuities by period, and entry into the landmark cohort
* Requires rddensity (Cattaneo, Jansson and Ma), version 3.0 from github.com/rdpackages/rddensity
use "$W/base.dta", clear
topen
* A: local polynomial density test (rddensity, default options) in each period; the change between periods is the difference of
* the two density discontinuities (density just above minus just below the threshold) with summed variances
foreach p in 0 1 {
    rddensity s if post == `p', c(0)
    local fl`p' = e(f_ql)
    local fr`p' = e(f_qr)
    local se`p' = e(se_q)
    local P`p' = e(pv_q)
    local N`p' = e(N_h_l) + e(N_h_r)
    local J`p' = ln(e(f_qr)/e(f_ql))
}
local Jd = `J1' - `J0'
local Nd = `N0' + `N1'
local Pd = 2*normal(-abs(((`fr1' - `fl1') - (`fr0' - `fl0'))/sqrt(`se1'^2 + `se0'^2)))
prow "A. Density of the assignment variable in each period and the change between periods"
prow "Quantity" "Log-density jump" "Density ratio (above/below)" "P value" "Admissions"
foreach k in 0 1 d {
    local lab = cond("`k'" == "0", "Before implementation", cond("`k'" == "1", "After implementation", "Difference (after minus before)"))
    local n = `N`k''
    fnum `J`k'' 3
    local a "`r(s)'"
    fnum `=exp(`J`k'')' 2
    local b "`r(s)'"
    fp `P`k''
    prow "`lab'" "`a'" "`b'" "`r(s)'" "`n'"
}

* B: covariate continuity after implementation (binary covariates in percentage points)
prow "B. Continuity of covariates at the threshold, after implementation"
prow "" "±5" "±8"
prow "Covariate" "Discontinuity" "P value" "Discontinuity" "P value"
local L_age_z "Age (standardized)"
local L_male "Male sex"
local L_cci "Charlson comorbidity index"
local L_htn "Hypertension"
local L_sofa "SOFA score at admission"
local L_surgical_dept "Surgical specialty"
local L_summer "Admitted in summer"
local L_fall "Admitted in autumn"
local L_winter "Admitted in winter"
local L_rv_news "National Early Warning Score, first 24 h"
local BIN male htn surgical_dept summer fall winter sepsis hB hC
foreach v in $COVS rv_news {
    local c
    foreach h in 5 8 {
        preserve
        qui keep if post == 1 & abs(s) < `h'
        mkw `h' tri
        qui gen double Ds = D*s
        qui regress `v' D s Ds hB hC [pw=kw], vce(cluster clust)
        seadj
        local m = cond(strpos(" `BIN' ", " `v' "), 100, 1)
        local est = `m'*_b[D]
        local pv = 2*normal(-abs(_b[D]/(_se[D]*r(adj))))
        restore
        fnum `est' 2
        local c `"`c' "`r(s)'""'
        fp `pv'
        local c `"`c' "`r(s)'""'
    }
    prow "`L_`v''" `c'
}

* C: covariate discontinuities before and after implementation and their difference (window 5)
prow "C. Covariate discontinuities at the threshold before and after implementation, and their difference (window ±5)"
prow "" "Before implementation" "After implementation" "Between periods"
prow "Covariate" "Discontinuity" "P value" "Discontinuity" "P value" "Difference" "P value"
local L_age "Age, years"
local L_sepsis "Sepsis"
local L_hB "Hospital B"
local L_hC "Hospital C"
foreach v in age male cci htn sofa surgical_dept sepsis summer fall winter hB hC rv_news {
    preserve
    qui keep if abs(s) < 5
    mkw 5 tri
    qui gen double Ds = D*s
    qui gen double pD = post*D
    qui gen double ps = post*s
    qui gen double pDs = post*D*s
    qui gen double hB_post = hB*post
    qui gen double hC_post = hC*post
    local hosp hB hC hB_post hC_post
    if "`v'" == "hB" | "`v'" == "hC" local hosp
    qui regress `v' D s Ds post pD ps pDs `hosp' [pw=kw], vce(cluster clust)
    seadj
    local adj = r(adj)
    local m = cond(strpos(" `BIN' ", " `v' "), 100, 1)
    local e0 = `m'*_b[D]
    local p0 = 2*normal(-abs(_b[D]/(_se[D]*`adj')))
    local ed = `m'*_b[pD]
    local pd = 2*normal(-abs(_b[pD]/(_se[pD]*`adj')))
    qui lincom D + pD
    local e1 = `m'*r(estimate)
    local p1 = 2*normal(-abs(r(estimate)/(r(se)*`adj')))
    restore
    local c
    foreach k in 0 1 d {
        fnum `e`k'' 2
        local c `"`c' "`r(s)'""'
        fp `p`k''
        local c `"`c' "`r(s)'""'
    }
    prow "`L_`v''" `c'
}

* D: entry into the landmark cohort (all admissions with a score in the first 24 h)
prow "D. Entry into the landmark cohort at the threshold"
prow "" "Difference-in-discontinuities" "After implementation" "Before implementation"
prow "Check" "Window" "Events" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "OR (95% CI)" "P value"
use "paper_data_v9.dta", clear
keep if rv_dec < .
gen double s    = rv_dec - $CUT
gen byte   D    = (s >= 0)
gen byte   post = treat
gen byte   excl24  = (h_stay <= 24)
gen byte   died24  = (h_stay <= 24 & death == 1)
gen byte   disch24 = (h_stay <= 24 & death == 0)
foreach v in excl24 died24 disch24 {
    local lab = cond("`v'" == "excl24", "Not in cohort at 24 h (died or discharged)", cond("`v'" == "died24", "Died before 24 h", "Discharged alive before 24 h"))
    foreach h in 5 8 {
        trio, h(`h') outcome(`v')
        foreach x in dd ddlo ddhi ddp ev po polo pohi pop pr prlo prhi prp {
            local `x' = r(`x')
        }
        orci `dd' `ddlo' `ddhi' -
        local a "`r(s)'"
        fp `ddp'
        local b "`r(s)'"
        orci `po' `polo' `pohi' -
        local c "`r(s)'"
        fp `pop'
        local d "`r(s)'"
        orci `pr' `prlo' `prhi' -
        local e "`r(s)'"
        fp `prp'
        local rl
        if `h' == 5 local rl "`lab'"
        prow "`rl'" "±`h'" "`ev'" "`a'" "`b'" "`c'" "`d'" "`e'" "`r(s)'"
    }
}
tsave "eTable 4"
