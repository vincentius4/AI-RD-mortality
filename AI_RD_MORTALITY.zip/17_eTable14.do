* eTable 14. Reference-time rules R0-R9 for patients below the threshold (window 5, hospitals A-C)
topen
prow "Marker" "Rule for unalerted patients" "Median reference time, h" "DiD-RD" "Post-RD" "Pre-RD"
prow "" "" "" "OR (95% CI)" "P value" "OR (95% CI)" "P value" "OR" "P value"
local RL0 "R0 (primary): 24-h maximum"
local RL1 "R1: first value ≥84.5"
local RL2 "R2: first value ≥79.5"
local RL3 "R3: within 1 point of own maximum"
local RL4 "R4: within 2.5 points of own maximum"
local RL5 "R5: within 5 points of own maximum"
local RL6 "R6: 24-h maximum, both sides"
local RL7 "R7: within 1 point, both sides"
local RL8 "R8: matched above-threshold patient"
local RL9 "R9: hospital-period median"
foreach y in vital_any_A2h_any o2_escalation_A1h_new {
    forvalues r = 0/9 {
        use "rules_t90_v1.dta", clear
        qui keep if rule == `r'
        drop rule
        merge 1:1 adm_id using "$W/base.dta", keep(match) nogen
        qui summarize t0hr if s < 0 & abs(s) < 5, detail
        local med = string(r(p50), "%4.1f")
        trio, h(5) outcome(`y')
        foreach x in dd ddlo ddhi ddp po polo pohi pop pr prp {
            local `x' = r(`x')
        }
        orci `dd' `ddlo' `ddhi' to
        local a "`r(s)'"
        fp `ddp'
        local b "`r(s)'"
        orci `po' `polo' `pohi' to
        local c "`r(s)'"
        fp `pop'
        local d "`r(s)'"
        fnum `pr' 2
        local e "`r(s)'"
        fp `prp'
        local ml
        if `r' == 0 local ml = cond("`y'" == "vital_any_A2h_any", "VS ≤2 h (Figure 3)", "O2 ≤1 h, new")
        prow "`ml'" "`RL`r''" "`med'" "`a'" "`b'" "`c'" "`d'" "`e'" "`r(s)'"
    }
}
tsave "eTable 14"
