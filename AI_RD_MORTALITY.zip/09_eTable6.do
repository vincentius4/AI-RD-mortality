* eTable 6. Pandemic period and calendar-year stability of the preimplementation discontinuity
use "$W/base.dta", clear
topen
prow "A. Sensitivity to the pandemic period in the preimplementation data"
prow "" "Single RD before implementation" "Difference-in-discontinuities"
prow "Sample" "Window" "Admissions" "OR (95% CI)" "P value" "OR (95% CI)" "P value"
foreach k in 0 6 12 {
    local lab = cond(`k' == 0, "Full preimplementation period", cond(`k' == 6, "Excluding January to June 2022", "Excluding all of 2022"))
    foreach h in 5 8 {
        preserve
        if `k' > 0 qui drop if post == 0 & t <= `k'
        qui count if post == 0
        fn `r(N)'
        local n "`r(s)'"
        srd, h(`h') post(0)
        local p = r(p)
        orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' -
        local a "`r(s)'"
        fp `p'
        local b "`r(s)'"
        didisc, h(`h')
        local p = r(p)
        orci `=exp(r(b))' `=exp(r(b) - 1.96*r(se))' `=exp(r(b) + 1.96*r(se))' -
        local c "`r(s)'"
        fp `p'
        local rl
        if `h' == 5 local rl "`lab'"
        prow "`rl'" "±`h'" "`n'" "`a'" "`b'" "`c'" "`r(s)'"
        restore
    }
}
prow "B. Stability of the preimplementation discontinuity across calendar years"
prow "" "Preimplementation discontinuity"
prow "Preimplementation period" "Window" "Deaths" "Admissions" "OR (95% CI)" "P value" "P value for equality"
foreach h in 5 8 {
    preserve
    qui keep if post == 0 & abs(s) < `h'
    mkw `h' tri
    qui gen double Ds = D*s
    qui gen byte y22 = (t <= 12)
    foreach y in 1 0 {
        qui count if y22 == `y' & death == 1
        local dth`y' = r(N)
        qui count if y22 == `y'
        local nn`y' = r(N)
        qui logit death D s Ds hB hC $COVS [pw=kw] if y22 == `y', vce(cluster clust) iter(100)
        seadj
        local b`y' = _b[D]
        local se`y' = _se[D]*r(adj)
    }
    restore
    local peq = 2*normal(-abs((`b1' - `b0')/sqrt(`se1'^2 + `se0'^2)))
    foreach y in 1 0 {
        orci `=exp(`b`y'')' `=exp(`b`y'' - 1.96*`se`y'')' `=exp(`b`y'' + 1.96*`se`y'')' -
        local a "`r(s)'"
        fp `=2*normal(-abs(`b`y''/`se`y''))'
        local b "`r(s)'"
        if `y' == 1 {
            fp `peq'
            local e "`r(s)'"
        }
        else local e "NA"
        local yl = cond(`y' == 1, "2022", "2023 onwards")
        prow "`yl'" "±`h'" "`dth`y''" "`nn`y''" "`a'" "`b'" "`e'"
    }
}
tsave "eTable 6"
